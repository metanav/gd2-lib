#define LOAD_ASSETS()  GD.safeload("mono.gd2");
#define GREEN_HANDLE 0
#define GREEN_WIDTH 128
#define GREEN_HEIGHT 128
#define GREEN_CELLS 1
#define ASSETS_END 8192UL
static const shape_t GREEN_SHAPE = {0, 128, 128, 0};
